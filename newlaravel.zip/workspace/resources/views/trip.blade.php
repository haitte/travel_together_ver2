@extends('layouts.app')
  
  
            
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Trip Plan</div>

                <div class="panel-body">




                <div class="row">
                 <form class="form-horizontal" method="POST" action="{{ url('/addTrip') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('trip_title') ? ' has-error' : '' }}">
                            <label for="trip_title" class="col-md-4 control-label">Title</label>

                            <div class="col-md-6">
                                <input id="trip_title" type="text" class="form-control" name="trip_title" value="{{ old('trip_title') }}" required autofocus>
                                  @if ($errors->has('trip_title'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('trip_title') }}</strong>
                                    </span>
                                @endif
                                
                            </div>
                        </div>
                        
                        <div class="form-group{{ $errors->has('country_id') ? ' has-error' : '' }}">
                            <label for="country_id" class="col-md-4 control-label">Country</label>

                            <div class="col-md-6">
                                <select id="country_id" type="country_id" class="form-control" name="country_id" required>
                                    
                                    <option value="">Select</option>
                                     @if(count($countries) > 0)
                                        @foreach($countries->all() as $country)
                                            <option value="{{$country->id}}">{{$country->country}}</option>
                                        @endforeach
                                    @endif

                                </select>

                               
                            </div>
                        </div>
                       
                        <div class="form-group{{ $errors->has('city_id') ? ' has-error' : '' }}">
                            <label for="city_id" class="col-md-4 control-label">City</label>

                            <div class="col-md-6">
                                <select id="city_id" type="city_id" class="form-control" name="city_id" required>
                                    
                                    <option value="">Select</option>
                                     @if(count($cities) > 0)
                                        @foreach($cities->all() as $city)
                                            <option value="{{$city->id}}">{{$city->city}}</option>
                                        @endforeach
                                    @endif

                                </select>

                               
                            </div>
                        </div>
                       
                       
                         <div class="form-group{{ $errors->has('date_from') ? ' has-error' : '' }}">
                            <label for="date_from" class="col-md-4 control-label">From</label></label>

                            
                             <div class="col-md-6">
                                <input id="datepicker" type="text" class="form-control" name="date_from" value="{{ old('date_from') }}" required autofocus>
                                @if ($errors->has('date_form'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('date_form') }}</strong>
                                    </span>
                                @endif
                                
                            </div>
                        </div>
                        
                        <div class="form-group{{ $errors->has('date_to') ? ' has-error' : '' }}">
                            <label for="date_to" class="col-md-4 control-label">To</label>

                            
                             <div class="col-md-6">
                                <input id="datepicker" type="text" class="form-control" name="date_to" value="{{ old('date_to') }}" required autofocus>
                                     @if ($errors->has('date_to'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('date_to') }}</strong>
                                    </span>
                                @endif
                                
                            </div>
                        </div>
                        
                        
                          <div class="form-group{{ $errors->has('max_people') ? ' has-error' : '' }}">
                            <label for="max_people" class="col-md-4 control-label">Max.No of People</label>

                            <div class="col-md-6">
                                <input id="max_people" type="text" class="form-control" name="max_people" value="{{ old('max_people') }}" required autofocus>

                                   @if ($errors->has('max_people'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('max_people') }}</strong>
                                    </span>
                                @endif

                                </select>

                               
                            </div>
                        </div>
                        
                         <div class="form-group{{ $errors->has('description') ? ' has-error' : '' }}">
                            <label for="description" class="col-md-4 control-label">Description</label>

                            <div class="col-md-6">
                                <textarea id="description" rows="7" class="form-control" name="description" value="{{ old('description') }}" required></textarea>
                                @if ($errors->has('description'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('description') }}</strong>
                                    </span>
                                @endif
                                
                            </div>
                        </div>
                        
                    
                      
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Publish Trip
                                </button>
                            </div>
                        </div>
                    </form>
                
                </div>
                
                
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
