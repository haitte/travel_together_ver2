<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Country;
use App\City;

class TripController extends Controller
{
     public function trip()
    {
            $countries= Country::all();
            $cities= City::all();
         
        return view('trip',['countries' =>$countries,'cities'=>$cities]);
    }
    
     public function addTrip(Request $request)
    {
         $this->validate($request, [
            'trip_title' => 'required',
            'country_id' => 'required',
            'city_id' => 'required',
            'date_form' => 'required',
            'date_to' => 'required',
            'max_people' => 'required',
            'description' => 'required'
            ]);
            
        $trips = new Trip;
            $trips->users_id=Auth::user()->id;
            $trips->trip_title = $request->input('trip_title');
            $trips->country_id = $request->input('country_id');
            $trips->city_id = $request->input('city_id');
            $trips->date_form = $request->input('date_form');
            $trips->date_to = $request->input('date_to');
            $trips->max_people = $request->input('max_people');
             $trips->description = $request->input('description');
        $trips->save();
        return redirect('/home')->with('response','Trip Added Successfully');
    }
}
