<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Country;

class CountryController extends Controller
{
     public function country()
    {
        return view('country');
    }
    
    public function addCountry(Request $request)
    {
        $this->validate($request, [
            'country' => 'required'
            ]);
            
        $country = new Country;
        $country->country = $request->input('country');
        $country->save();
        return redirect('/country')->with('response','Country Added Successfully');
    }
}
