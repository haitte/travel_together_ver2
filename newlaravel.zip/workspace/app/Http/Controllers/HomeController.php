<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Profile;
use App\user;
use App\Post;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users_id = Auth::user()->id;
        $profile = DB::table('users')
                    ->join('profiles','users_id', '=','profiles.users_id')
                    ->select('users.*','profiles.*')
                    ->where(['profiles.users_id'=>$users_id])
                    ->first();
                    
        $posts= Post::paginate(2);
                    
        return view('home',['profile' => $profile,'posts' => $posts]);
    }
  
 
   
}
