<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\City;

class CityController extends Controller
{
     public function city()
    {
        return view('city');
    }
    
    public function addCity(Request $request)
    {
        $this->validate($request, [
            'city' => 'required'
            ]);
            
        $city = new City;
        $city->city = $request->input('city');
        $city->save();
        return redirect('/city')->with('response','City Added Successfully');
    }
}
