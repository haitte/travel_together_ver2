<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
                
            <div class="panel panel-default text-center">
                <div class="panel-heading">Post View</div>

                <div class="panel-body">
                   <div class="col-md-4">
                      <ul class="list-group">
                          
                          
                          <?php if(count($categories) > 0): ?>
                              <?php $__currentLoopData = $categories->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li class="list-group-item"><a href='<?php echo e(url("category/{$category->
                                  id}")); ?>'><?php echo e($category->$category); ?></a></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                          <?php else: ?>
                          <p>No Category found</p>
                          <?php endif; ?>
                          
                      </ul>
                   </div>
                    
                   <div class="col-md-8">
                        <?php if(count($posts) > 0): ?>
                            <?php $__currentLoopData = $posts->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h4><?php echo e($post->post_title); ?></h4>
                                <img src="<?php echo e($post->post_image); ?>" alt="">
                                <p><?php echo e(($post->post_body)); ?></p>
                                
                                
                                <ul class="nav nav-pills">
                                    <li role="presentation">
                                        <a href='<?php echo e(url("/like/{$post->id}")); ?>'>
                                            <span class="fa fa-thumbs-up" aria-hidden="true" >Like (<?php echo e($likeCtr); ?>)</span>
                                        </a>
                                    </li>
                                </ul>
                                
                                 <ul class="nav nav-pills">
                                    <li role="presentation">
                                        <a href='<?php echo e(url("/dislike/{$post->id}")); ?>'>
                                            <span class="fa fa-thumbs-down" aria-hidden="true" >Dislike (<?php echo e($dislikeCtr); ?>)</span>
                                        </a>
                                    </li>
                                </ul>
                                
                                 <ul class="nav nav-pills">
                                    <li role="presentation">
                                        <a href='<?php echo e(url("/comment/{$post->id}")); ?>'>
                                            <span class="fa fa-comment-o" aria-hidden="true" >Comment</span>
                                        </a>
                                    </li>
                                </ul>
                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        <?php else: ?>
                        <p>No Post avaiable</p>
                        <?php endif; ?>
                        
                        <form method="post" action='<?php echo e(url("/comment/{$post->id}")); ?>'>
                            <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <textarea id="comment" rows="6" class="form-control" name="comment" required autofocus>
                                        
                                    </textarea>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success btn-lg btn-block">PostComment</button>
                                </div>
                        </form>
                        
                        
                        <h3>Comment</h3>
                        
                         <?php if(count($comments) > 0): ?>
                            <?php $__currentLoopData = $comments->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($comment->comment); ?></p>
                            <p>Posted by:<?php echo e($comment->name); ?></p>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <p>No post Avai</p>
                        <?php endif; ?>
                        
                        
                        
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>