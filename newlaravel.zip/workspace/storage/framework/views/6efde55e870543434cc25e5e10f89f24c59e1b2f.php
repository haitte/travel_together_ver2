  
  
            
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Trip Plan</div>

                <div class="panel-body">




                <div class="row">
                 <form class="form-horizontal" method="POST" action="<?php echo e(url('/addTrip')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('trip_title') ? ' has-error' : ''); ?>">
                            <label for="trip_title" class="col-md-4 control-label">Title</label>

                            <div class="col-md-6">
                                <input id="trip_title" type="text" class="form-control" name="trip_title" value="<?php echo e(old('trip_title')); ?>" required autofocus>
                                  <?php if($errors->has('trip_title')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('trip_title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('country_id') ? ' has-error' : ''); ?>">
                            <label for="country_id" class="col-md-4 control-label">Country</label>

                            <div class="col-md-6">
                                <select id="country_id" type="country_id" class="form-control" name="country_id" required>
                                    
                                    <option value="">Select</option>
                                     <?php if(count($countries) > 0): ?>
                                        <?php $__currentLoopData = $countries->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->country); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>

                               
                            </div>
                        </div>
                       
                        <div class="form-group<?php echo e($errors->has('city_id') ? ' has-error' : ''); ?>">
                            <label for="city_id" class="col-md-4 control-label">City</label>

                            <div class="col-md-6">
                                <select id="city_id" type="city_id" class="form-control" name="city_id" required>
                                    
                                    <option value="">Select</option>
                                     <?php if(count($cities) > 0): ?>
                                        <?php $__currentLoopData = $cities->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->city); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>

                               
                            </div>
                        </div>
                       
                       
                         <div class="form-group<?php echo e($errors->has('date_from') ? ' has-error' : ''); ?>">
                            <label for="date_from" class="col-md-4 control-label">From</label></label>

                            
                             <div class="col-md-6">
                                <input id="datepicker" type="text" class="form-control" name="date_from" value="<?php echo e(old('date_from')); ?>" required autofocus>
                                <?php if($errors->has('date_form')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('date_form')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('date_to') ? ' has-error' : ''); ?>">
                            <label for="date_to" class="col-md-4 control-label">To</label>

                            
                             <div class="col-md-6">
                                <input id="datepicker" type="text" class="form-control" name="date_to" value="<?php echo e(old('date_to')); ?>" required autofocus>
                                     <?php if($errors->has('date_to')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('date_to')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                        
                        
                          <div class="form-group<?php echo e($errors->has('max_people') ? ' has-error' : ''); ?>">
                            <label for="max_people" class="col-md-4 control-label">Max.No of People</label>

                            <div class="col-md-6">
                                <input id="max_people" type="text" class="form-control" name="max_people" value="<?php echo e(old('max_people')); ?>" required autofocus>

                                   <?php if($errors->has('max_people')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('max_people')); ?></strong>
                                    </span>
                                <?php endif; ?>

                                </select>

                               
                            </div>
                        </div>
                        
                         <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <label for="description" class="col-md-4 control-label">Description</label>

                            <div class="col-md-6">
                                <textarea id="description" rows="7" class="form-control" name="description" value="<?php echo e(old('description')); ?>" required></textarea>
                                <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                        
                    
                      
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Publish Trip
                                </button>
                            </div>
                        </div>
                    </form>
                
                </div>
                
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>