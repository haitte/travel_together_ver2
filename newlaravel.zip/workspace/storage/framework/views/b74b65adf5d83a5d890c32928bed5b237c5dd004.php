<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Post</div>

                <div class="panel-body">




                <div class="row">
                 <form class="form-horizontal" method="POST" action="<?php echo e(url('/addPost')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('post_title') ? ' has-error' : ''); ?>">
                            <label for="post_title" class="col-md-4 control-label">Title</label>

                            <div class="col-md-6">
                                <input id="post_title" type="text" class="form-control" name="post_title" value="<?php echo e(old('post_title')); ?>" required autofocus>

                                <?php if($errors->has('post_title')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('post_title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('post_body') ? ' has-error' : ''); ?>">
                            <label for="post_body" class="col-md-4 control-label">Post Body</label>

                            <div class="col-md-6">
                                <textarea id="post_body" rows="7" class="form-control" name="post_body" value="<?php echo e(old('post_body')); ?>" required></textarea>

                                <?php if($errors->has('post_body')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('post_body')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                         <div class="form-group<?php echo e($errors->has('post_image') ? ' has-error' : ''); ?>">
                            <label for="post_image" class="col-md-4 control-label">Post_image</label>

                            <div class="col-md-6">
                                <input id="post_image" type="file" class="form-control" name="post_image" required>

                                <?php if($errors->has('post_image')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('post_image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('category_id') ? ' has-error' : ''); ?>">
                            <label for="category_id" class="col-md-4 control-label">Category</label>

                            <div class="col-md-6">
                                <select id="category_id" type="category_id" class="form-control" name="category_id" required>
                                    
                                    <option value="">Select</option>
                                    <?php if(count($categories) > 0): ?>
                                        <?php $__currentLoopData = $categories->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>

                                <?php if($errors->has('category_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('category_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                       
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Publish Post
                                </button>
                            </div>
                        </div>
                    </form>
                
                </div>
                
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>